﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbDays = New System.Windows.Forms.Label()
        Me.lbUnits = New System.Windows.Forms.Label()
        Me.tbUnits = New System.Windows.Forms.TextBox()
        Me.lbEmployee1 = New System.Windows.Forms.Label()
        Me.tbEmployee1 = New System.Windows.Forms.TextBox()
        Me.tbEmployee2 = New System.Windows.Forms.TextBox()
        Me.tbEmployee3 = New System.Windows.Forms.TextBox()
        Me.lbEmployee1Output = New System.Windows.Forms.Label()
        Me.lbEmployee2Output = New System.Windows.Forms.Label()
        Me.lbEmployee3Output = New System.Windows.Forms.Label()
        Me.lbAveragePerDay = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lbEmployee2 = New System.Windows.Forms.Label()
        Me.lbEmployee3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbDays
        '
        Me.lbDays.Location = New System.Drawing.Point(23, 12)
        Me.lbDays.Name = "lbDays"
        Me.lbDays.Size = New System.Drawing.Size(100, 23)
        Me.lbDays.TabIndex = 0
        Me.lbDays.Text = "Day 1"
        '
        'lbUnits
        '
        Me.lbUnits.Location = New System.Drawing.Point(23, 36)
        Me.lbUnits.Name = "lbUnits"
        Me.lbUnits.Size = New System.Drawing.Size(39, 23)
        Me.lbUnits.TabIndex = 1
        Me.lbUnits.Text = "Units:"
        '
        'tbUnits
        '
        Me.tbUnits.Location = New System.Drawing.Point(68, 32)
        Me.tbUnits.Name = "tbUnits"
        Me.tbUnits.Size = New System.Drawing.Size(50, 20)
        Me.tbUnits.TabIndex = 2
        '
        'lbEmployee1
        '
        Me.lbEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEmployee1.Location = New System.Drawing.Point(22, 65)
        Me.lbEmployee1.Name = "lbEmployee1"
        Me.lbEmployee1.Size = New System.Drawing.Size(100, 23)
        Me.lbEmployee1.TabIndex = 3
        Me.lbEmployee1.Text = "Employee 1"
        Me.lbEmployee1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'tbEmployee1
        '
        Me.tbEmployee1.Location = New System.Drawing.Point(13, 87)
        Me.tbEmployee1.Multiline = True
        Me.tbEmployee1.Name = "tbEmployee1"
        Me.tbEmployee1.Size = New System.Drawing.Size(119, 127)
        Me.tbEmployee1.TabIndex = 4
        '
        'tbEmployee2
        '
        Me.tbEmployee2.Location = New System.Drawing.Point(139, 87)
        Me.tbEmployee2.Multiline = True
        Me.tbEmployee2.Name = "tbEmployee2"
        Me.tbEmployee2.Size = New System.Drawing.Size(119, 127)
        Me.tbEmployee2.TabIndex = 5
        '
        'tbEmployee3
        '
        Me.tbEmployee3.Location = New System.Drawing.Point(264, 87)
        Me.tbEmployee3.Multiline = True
        Me.tbEmployee3.Name = "tbEmployee3"
        Me.tbEmployee3.Size = New System.Drawing.Size(119, 127)
        Me.tbEmployee3.TabIndex = 6
        '
        'lbEmployee1Output
        '
        Me.lbEmployee1Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbEmployee1Output.Location = New System.Drawing.Point(14, 219)
        Me.lbEmployee1Output.Name = "lbEmployee1Output"
        Me.lbEmployee1Output.Size = New System.Drawing.Size(119, 22)
        Me.lbEmployee1Output.TabIndex = 7
        Me.lbEmployee1Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbEmployee2Output
        '
        Me.lbEmployee2Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbEmployee2Output.Location = New System.Drawing.Point(139, 219)
        Me.lbEmployee2Output.Name = "lbEmployee2Output"
        Me.lbEmployee2Output.Size = New System.Drawing.Size(119, 22)
        Me.lbEmployee2Output.TabIndex = 8
        Me.lbEmployee2Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbEmployee3Output
        '
        Me.lbEmployee3Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbEmployee3Output.Location = New System.Drawing.Point(264, 219)
        Me.lbEmployee3Output.Name = "lbEmployee3Output"
        Me.lbEmployee3Output.Size = New System.Drawing.Size(119, 22)
        Me.lbEmployee3Output.TabIndex = 9
        Me.lbEmployee3Output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbAveragePerDay
        '
        Me.lbAveragePerDay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbAveragePerDay.Location = New System.Drawing.Point(14, 244)
        Me.lbAveragePerDay.Name = "lbAveragePerDay"
        Me.lbAveragePerDay.Size = New System.Drawing.Size(365, 22)
        Me.lbAveragePerDay.TabIndex = 10
        Me.lbAveragePerDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(13, 270)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(120, 23)
        Me.btnEnter.TabIndex = 11
        Me.btnEnter.Text = "&Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(139, 269)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(119, 23)
        Me.btnReset.TabIndex = 12
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(264, 270)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(119, 23)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lbEmployee2
        '
        Me.lbEmployee2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEmployee2.Location = New System.Drawing.Point(147, 64)
        Me.lbEmployee2.Name = "lbEmployee2"
        Me.lbEmployee2.Size = New System.Drawing.Size(100, 23)
        Me.lbEmployee2.TabIndex = 14
        Me.lbEmployee2.Text = "Employee 2"
        Me.lbEmployee2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lbEmployee3
        '
        Me.lbEmployee3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEmployee3.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lbEmployee3.Location = New System.Drawing.Point(283, 62)
        Me.lbEmployee3.Name = "lbEmployee3"
        Me.lbEmployee3.Size = New System.Drawing.Size(89, 23)
        Me.lbEmployee3.TabIndex = 15
        Me.lbEmployee3.Text = "Employee 3"
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(391, 299)
        Me.Controls.Add(Me.lbEmployee3)
        Me.Controls.Add(Me.lbEmployee2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lbAveragePerDay)
        Me.Controls.Add(Me.lbEmployee3Output)
        Me.Controls.Add(Me.lbEmployee2Output)
        Me.Controls.Add(Me.lbEmployee1Output)
        Me.Controls.Add(Me.tbEmployee3)
        Me.Controls.Add(Me.tbEmployee2)
        Me.Controls.Add(Me.tbEmployee1)
        Me.Controls.Add(Me.lbEmployee1)
        Me.Controls.Add(Me.tbUnits)
        Me.Controls.Add(Me.lbUnits)
        Me.Controls.Add(Me.lbDays)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Semester Average by Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbDays As Label
    Friend WithEvents lbUnits As Label
    Friend WithEvents tbUnits As TextBox
    Friend WithEvents lbEmployee1 As Label
    Friend WithEvents tbEmployee1 As TextBox
    Friend WithEvents tbEmployee2 As TextBox
    Friend WithEvents tbEmployee3 As TextBox
    Friend WithEvents lbEmployee1Output As Label
    Friend WithEvents lbEmployee2Output As Label
    Friend WithEvents lbEmployee3Output As Label
    Friend WithEvents lbAveragePerDay As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lbEmployee2 As Label
    Friend WithEvents lbEmployee3 As Label
End Class
