﻿'Program:       AverageUnitsShipped_Employee
'Author:        Avindi Premaratne
'Date:          February 22th 2019  
'Description:   A program which calculates the average units shipped by employee per week by taking the input for each day in the week
''              calculate and display the average of the units of each employee and finally calculating the average units per day to the user.


Option Strict On
Public Class frmMain
    Const numDays As Integer = 7                    'stores the value of number of days per week
    Const numEmployees As Integer = 3               'stores the value of number of employees
    Const minNumber As Integer = 0                  'stores the minimum number of inputs
    Const maxNumber As Integer = 1000               'stores the maximum number of inputs

    Dim userInput As Integer = 0                    'stores the user input
    Dim currentDay As Integer = 1                   'stores the value of the current day
    Dim totalUnits As Double = 0.0                  'stores the value of total number of units
    Dim totalAverage As Double = 0.0                'stores the value of overall average units per day by employee
    Dim currentEmployee As Integer = 1              'stores the current value of the employee number
    Dim averageUnit As Double = 0.0                 'stores the average units of each employee

    'Declaring the array to store the units
    Dim employeeUnits(numDays, numEmployees) As Integer

    'Subroutine to reset all the values and enables all the controls for the reset button
    Sub resetForm()
        tbUnits.Clear()
        tbUnits.Enabled = True
        tbEmployee1.Clear()
        tbEmployee2.Clear()
        tbEmployee3.Clear()

        lbEmployee1Output.Text = ""
        lbEmployee2Output.Text = ""
        lbEmployee3Output.Text = ""
        lbAveragePerDay.Text = ""
        lbDays.Text = "Day 1"

        currentDay = 1
        currentEmployee = 1

        btnEnter.Enabled = True

    End Sub

    'validInput Function to check whether the user input is valid
    Private Function validInput(ByRef tbUnits As TextBox) As Boolean

        'Checks if the input is numeric and between 0 and 100
        If Integer.TryParse(tbUnits.Text, userInput) Then
            If (userInput >= minNumber And userInput <= maxNumber) Then
                Return True

                'Else display error message that the value must be between 0 and 1000
            Else
                MessageBox.Show("The value must be between " & minNumber & " and " & maxNumber)
                Return False
            End If

            'Else display error message that the value must be numeric
        Else
            MessageBox.Show("The value must be numeric.")
            Return False
        End If
    End Function
    Private Sub FrmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        'Dclaring variable sum to store the sum of units
        Dim sum As Integer = 0

        'Declaring an array to store the labels used to display the average
        Dim employeeLabel As Label() = {lbEmployee1Output, lbEmployee2Output, lbEmployee3Output}

        'Declaring an array to store the textboxes used to display the units entered by the user
        Dim employeeTextbox As TextBox() = {tbEmployee1, tbEmployee2, tbEmployee3}

        'Calling the function and assigns the user input from the textbox to the the variable in the function
        If validInput(tbUnits) Then
            userInput = CInt(tbUnits.Text)
            tbUnits.Text = ""

            'Assigns the user's input to the array
            employeeUnits(currentDay - 1, currentEmployee - 1) = userInput

            'Pass the value to the textbox to display what user have entered
            employeeTextbox(currentEmployee - 1).Text += userInput.ToString & vbCrLf

            'If condition to check if the current day is equal to 7 
            If currentDay = numDays Then

                'For loop is used to calculate the sum of units per week
                For counter As Integer = 1 To numDays
                    sum += employeeUnits(counter - 1, currentEmployee - 1)
                Next

                'Calculates the average units per employee
                averageUnit = CDbl(sum / numDays)

                'Assign the value to another variable to calculate the average unts per day
                totalAverage += averageUnit

                'Displays the average units per employee
                employeeLabel(currentEmployee - 1).Text = "Average: " & Math.Round(averageUnit, 2).ToString()

                'Increment the currentEmployee 
                currentEmployee = currentEmployee + 1

                'Sets the current day to zero
                currentDay = 0
            End If

            'Checks if the current day is greater than 7
            If (currentDay > numDays) Then
                'Displays the text as "Done"
                lbDays.Text = "Done"
            Else
                'Sets the text of the Day label to display the number of days
                lbDays.Text = "Day " & currentDay + 1

                'Increments the currentDay variable
                currentDay = currentDay + 1
            End If

            'If condition to check if the array is filled with values
            If currentDay < numDays And currentEmployee > numEmployees Then

                'Disable the textbox for the user input and enter button
                tbUnits.Enabled = False
                btnEnter.Enabled = False

                'Sets forcus to the reset button
                btnReset.Focus()

                'Sets the text of the days label to "Done"
                lbDays.Text = "Done"

                'Declares a variable to store the average per day
                Dim companyAverage As Double = 0

                'Calculating the average
                companyAverage = CDbl(totalAverage / numEmployees)

                'Display the average per day
                lbAveragePerDay.Text = ("Average per day: " & Math.Round(companyAverage, 2).ToString())
            End If

        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Exit the appplication
        Application.Exit()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'Calling the resetForm function to reset all the values
        resetForm()
    End Sub
End Class
